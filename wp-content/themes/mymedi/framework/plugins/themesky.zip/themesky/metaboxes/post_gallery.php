<?php 
$options = array();

$options[] = array(
				'id'		=> 'gallery'
				,'label'	=> ''
				,'desc'		=> ''
				,'type'		=> 'gallery'
			);
			
?>